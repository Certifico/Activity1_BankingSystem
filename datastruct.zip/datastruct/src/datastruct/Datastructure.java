/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datastruct;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author khian
 */
public class Datastructure {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Scanner scn = new Scanner(System.in);
      int[] array = new int [10];
      
        for (int i = 0; i < array.length; i++) {
            array[i] = scn.nextInt();
            
            System.out.println("Your Arrays:" + Arrays.toString(array));
        }
    }
  }