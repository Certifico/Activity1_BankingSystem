/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datastruct;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author khian
 */
public class Datastructure250823 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner scn = new Scanner(System.in);
        
        
        System.out.println("MENU");
        //INSERTION
        System.out.println("1. DEPOSIT");
        //DELETION
        System.out.println("2. WITHDRAW");
        //SORTING
        System.out.println("3. CHECK BALANCE");
        
        int input = scn.nextInt();
        
        if (input == 1) {
           Deposit();
        }
        else if (input == 2)  {
            System.out.println("Coming Soon");
        }
        else if (input == 3){
            System.out.println("Coming Soon");
        }
        else{
            System.out.println("Error 404");
        }
}
    public static void Deposit(){
        Scanner scn = new Scanner(System.in);
        System.out.println("Amount to Deposit: ");
        int amount = scn.nextInt();
        
        System.out.println("Bank Balance: " + (amount));
        
        System.out.println("Would you Like to Add More?: ");
        int choice = scn.nextInt();
        
        if (choice == 1) {
            System.out.println("Enter Amount: ");
            int newamount = scn.nextInt();
            System.out.println("Bank Balance: " + (amount + newamount));  
        } else {
            System.out.println("Thank you!! Come Again");
        }
}
    
}