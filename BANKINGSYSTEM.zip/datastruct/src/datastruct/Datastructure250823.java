/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datastruct;

import java.util.Scanner;

/**
 *
 * @author khian
 */
public class Datastructure250823 {
    
    private static final int MAX_TRANSACTIONS = 10;
    private static final int[] balance = new int[MAX_TRANSACTIONS];
    private static int transactionCount = 0;
    private static final Scanner scanner = new Scanner(System.in);
    
    public static void main(String[] args) {
    displayWelcomeMessage();
        showMenu();
    }

    public static void displayWelcomeMessage() {
        System.out.println("*******************************");
        System.out.println("*  Welcome to Khianne's Bank  *");
        System.out.println("*******************************\n");
    }

    public static void showMenu() {
        System.out.println("\nMENU");
        System.out.println("1. DEPOSIT");
        System.out.println("2. CHECKBALANCE");
        System.out.println("3. WITHDRAW");
        System.out.println("4. EXIT");

        int choice = getUserChoice(1, 4);

        switch (choice) {
            case 1:
                deposit();
                break;
            case 2:
                checkBalance();
                break;
            case 3:
                withdraw();
                break;
            case 4:
                scanner.close();
                System.out.println("Thank you for using Khianne's Bank!");
                break;
        }
    }

    public static void deposit() {
        clearConsole();
        System.out.println("AMOUNT TO DEPOSIT");
        System.out.println("1. 50");
        System.out.println("2. 300");
        System.out.println("3. 500");
        System.out.println("4. 800");
        System.out.println("5. 1000");
        System.out.println("6. 4000");

        int choice = getUserChoice(1, 6);

        int[] depositOptions = { 50, 300, 500, 800, 1000, 4000 };
        balance[transactionCount++] = depositOptions[choice - 1];

        System.out.println("\nSUCCESSFULL! NEW BALANCE: " + calculateTotalBalance());
        continueOperation();
    }

    public static void checkBalance() {
        clearConsole();
        System.out.println("BALANCE");
        System.out.println("*********************************");
        for (int i = 0; i < transactionCount; i++) {
            System.out.println((i + 1) + ". " + balance[i]);
        }
        System.out.println("*********************************\n");
        continueOperation();
    }

    public static void withdraw() {
        clearConsole();
        System.out.println("WITHDRAW");

        if (transactionCount == 0) {
            System.out.println("NOTHING TO WITHDRAW.");
            continueOperation();
            return;
        }

        System.out.println("AMOUNT TO WITHDRAW:");
        for (int i = 0; i < transactionCount; i++) {
            System.out.println((i + 1) + ". " + balance[i]);
        }

        int input = getUserChoice(1, transactionCount) - 1;
        int withdrawnAmount = balance[input];

        for (int i = input; i < transactionCount - 1; i++) {
            balance[i] = balance[i + 1];
        }
        transactionCount--;

        System.out.println("\nWITHDRAWED" + withdrawnAmount);
        System.out.println("REMAINING BALANCE: " + calculateTotalBalance());
        continueOperation();
    }

    public static int calculateTotalBalance() {
        int total = 0;
        for (int i = 0; i < transactionCount; i++) {
            total += balance[i];
        }
        return total;
    }

    public static void continueOperation() {
        System.out.print("\nPress ENTER to Continue...");
        scanner.nextLine();
        showMenu();
    }

    public static int getUserChoice(int min, int max) {
        int choice;
        while (true) {
            System.out.print("ENTER CHOICE: ");
            choice = scanner.nextInt();
            if (choice >= min && choice <= max) {
                break;
            }
            System.out.println("INVALID, TRY AGAIN.");
        }
        return choice;
    }

    public static void clearConsole() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }      
}
